<header id="masthead" class="site-header header-default  light">
	<div class="container">
		<div class="amy-inner">
			<div class="amy-left">
				<div id="amy-site-logo">
<a href="http://demo.amytheme.com/movie/demo/elementor-watch-online/">
<img src="http://demo.amytheme.com/movie/demo/elementor-watch-online/wp-content/uploads/sites/10/2022/05/img_66.png" alt="Elementor Watch Online">
</a>
</div>							</div>
			<div class="amy-right">
				<nav id="amy-site-nav" class="amy-site-navigation amy-primary-navigation">
<div class="menu-mainnav-container"><ul id="menu-mainnav" class="nav-menu"><li id="menu-item-438" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-438"><a href="<?php echo e(route('home'), false); ?>">Home</a></li>
<li id="menu-item-409" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-409"><a href="<?php echo e(route('allMovies'), false); ?>">Movie</a>

</li>
<li id="menu-item-613" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-613"><a href="#">Contact Us</a>

</li>
<li id="menu-item-616" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-616"><a href="http://demo.amytheme.com/movie/demo/elementor-watch-online/watch-online/?movie=kubo-and-the-two-strings">About Us</a></li>
</ul>
</div>
</nav>				
<div id="amy-menu-toggle"><a><span></span></a></div>							
</div>
		
</div>
	</div>
	<div id="amy-site-header-shadow"></div>
</header>
<?php /**PATH C:\Users\HP\Desktop\workspace\Movie\resources\views/user_interface/mainHeader.blade.php ENDPATH**/ ?>