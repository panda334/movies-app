<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard'), false); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
           <div class="flex justify-end m-2 p-2">
            <a href="<?php echo e(route('admincasts.create'), false); ?>" class="px-4 py-2 bg-indigo-500 hover:bg-indigo-700 rounded-lg text-white">New Caster</a>
           </div>
<div class="relative overflow-x-auto">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3">
                    FirstName
                </th>
                <th scope="col" class="px-6 py-3">
                    LastName
                </th>
                <th scope="col" class="px-6 py-3">
                    Job
                </th>
                <th scope="col" class="px-6 py-3">
                    Image
                </th>

             
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                
                <td class="px-6 py-4 text-sm font-medium text-gray-800 whitespace-nowrap dark:border-gray-700">
                    <?php echo e($cast->first_name, false); ?>

                </td>


                <td class="px-6 py-4 text-sm font-medium text-gray-800 whitespace-nowrap dark:text-white">
                    <?php echo e($cast->last_name, false); ?>

                </td>

                <td class="px-6 py-4 text-sm font-medium text-gray-800 whitespace-nowrap dark:text-white">
                    <?php echo e($cast->job, false); ?>

                </td>

                
                <td>
                    <img src="<?php echo e($cast->getFirstMediaUrl('images' , 'thumb' , 'cropped'), false); ?>" alt="Movie Image"">
                </td>

                <td class="py-4 px-6  text-sm font-medium text-gray-800 whitespace-nowrap dark:text-white">
                    <div class="flex space-x-2">
                   <a href="<?php echo e(route('admincasts.edit',$cast->id), false); ?>"
                     class="px-4 py-2 bg-green-500 hover:bg-green-700 rounded-lg text-white">Edit</a>
                   <form 
                   class="px-4 py-2 bg-red-500 hover-bg-red-700 rounded-lg text-white"
                   method="POST"
                   action="<?php echo e(route('admincasts.destroy',$cast->id), false); ?>"
                   onsubmit="return confirm('Are You Sure?');">
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('DELETE'); ?>
                   <button type="submit">Delete</button>
                   </form>
                    </div>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            
           
        </tbody>
    </table>
</div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\Desktop\workspace\Movie\resources\views/admin/cast/index.blade.php ENDPATH**/ ?>