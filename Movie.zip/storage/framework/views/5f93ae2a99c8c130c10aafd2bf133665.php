
<?php echo $__env->make('layouts.user_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" type="text/css" href="styles.css" />



<section class="main-content amy-movie single-movie layout-right has-banner">
    <div class="container">
        <div class="row">
                        <div class="col-md-8">
                <div class="page-content">
<article id="post-133" class="post-133 amy_movie type-amy_movie status-publish amy_genre-cartoon amy_genre-sci-fi amy_actor-alexander-cattly amy_actor-cartin-hollia amy_actor-humpray-richard amy_director-gally-peckin amy_director-mae-west">
			<div class="entry-top">
			<div class="entry-poster">
                <img class="" src="<?php echo e($movies->getFirstMediaUrl('images'), false); ?>" alt="Jumanji: Welcome to the Jungle">			
            </div>
			<div class="entry-info">
				<h1 class="entry-title p-name" itemprop="name headline">
                    <span>
                 <?php echo e($movies->name, false); ?>   
                    </span>
    
</h1>


<div class="entry-pg">
			<span class="pg">Hd</span>
	
			<span class="duration">
			<i class="fa fa-clock-o"></i>
			<?php echo e($movies->length, false); ?>  hour
            </span>
</div>

<ul class="info-list">
	        <li>
            <label>
                Actor:
            </label>
            <span>
                <?php $__currentLoopData = $movies->casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cast->job == 'actor'): ?>
                <?php echo e($cast->first_name, false); ?> <?php echo e($cast->last_name, false); ?>

                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
            </span>
        </li>
	
	        <li>
            <label>
                Director:
            </label>
            <span>
                <a >Gally Peckin</a>, 
                <a >Mae West</a>            
            </span>
        </li>
	
	        <li>
            <label>
                Genre:
            </label>
            <span>
                <?php $__currentLoopData = $movies->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($category->name, false); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </span>
        </li>
	
	        <li>
            <label>
                Release:
            </label>
            <span>
                <?php echo e($movies->date, false); ?>            
            </span>
        </li>
	
	        <li>
            <label>
                Language:
            </label>
            <span>
                <?php echo e($movies->language, false); ?>

            </span>
        </li>
	
	        <li>
            <label>
                IMDB Rating:
            </label>
            <span>
                <?php echo e($movies->rate, false); ?>         
            </span>
        </li>
	
	
	</ul>

    
    <a href="<?php echo e(route('watchOnline' , $movies->id), false); ?>" class="amy-redirect-watch-online" style="padding: 10px 25px; background: #071a01; color: #fff;">
        <span>
            WatchOnline        
        </span>
    </a>

     <?php $__currentLoopData = $movies->trailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <a href="<?php echo e($trailer->url, false); ?>" class="amy-redirect-watch-online" style="padding: 10px 25px; background: #fe0022; color: #fff;">
        <span>
            Trailer        
        </span>
    </a> 
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




   
    <a href="<?php echo e(route('download' , $movies->id), false); ?>" class="amy-redirect-watch-online" style="padding: 10px 25px; background: #fe7900; color: #fff;">
        <span>
            Download        
        </span>
    </a>



<div class="entry-action">
	<div class="mrate  no-rate">
					</div>
	<div class="entry-share">
		<label>Share:</label>
		<ul class="amy-social-links clearfix"><li><a href="https://www.facebook.com/sharer.php?u=http://demo.amytheme.com/movie/demo/elementor-watch-online/amy_movie/jumanji-welcome-to-the-jungle/" class="fab fa-facebook" target="_blank"></a></li><li><a href="http://www.twitter.com/share?url=http://demo.amytheme.com/movie/demo/elementor-watch-online/amy_movie/jumanji-welcome-to-the-jungle/" class="fab fa-twitter" target="_blank"></a></li><li><a href="http://pinterest.com/pin/create/button/?url=http://demo.amytheme.com/movie/demo/elementor-watch-online/amy_movie/jumanji-welcome-to-the-jungle/" class="fab fa-pinterest" target="_blank"></a></li></ul>	</div>
	<div class="clearfix"></div>
</div>
			</div>
		</div>
		<div class="clearfix"></div>
		
<div class="entry-content e-content" itemprop="description articleBody">
	<h3 class="info-name amy-title">Story</h3>
	<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, tota</p></div>

    
    <link rel="stylesheet" type="text/css" href="styles.css" />
 

</article>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</body>
</html><?php /**PATH C:\Users\HP\Desktop\workspace\Movie\resources\views/user_interface/single_movie.blade.php ENDPATH**/ ?>