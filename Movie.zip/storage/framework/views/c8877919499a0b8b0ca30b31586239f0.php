<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
 
        <title>FilePond Tutorial</title>
 
        <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
 
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    </head>
 
    <body>
        <form action="<?php echo e(route('uploadFile'), false); ?>" method="POST">
            <?php echo csrf_field(); ?>
 
            <input type="file"  class="filepond"/>
 
        </form>
    </body>
    <script src="node_modules/blueimp-file-upload/js/jquery.fileupload.js"></script>
    $('#fileupload').fileupload();
</html><?php /**PATH C:\Users\HP\Desktop\workspace\Movie\resources\views/upload/upload.blade.php ENDPATH**/ ?>