<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale(), false); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <title>Laravel Spatie Permission</title>
    <script src="<?php echo e(asset('js/app.js'), false); ?>" defer></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css'), false); ?>" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(route('admin'), false); ?>">
                    Back to the admin dashboard
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
    
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                       
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="nav-link" href="<?php echo e(route('login'), false); ?>"><?php echo e(('Login'), false); ?> </a></li>
                            <li><a class="nav-link" href="<?php echo e(route('register'), false); ?>"><?php echo e(('Register'), false); ?></a></li>
                        <?php else: ?>
                            <li><a class="nav-link" href="<?php echo e(route('adminusers.index'), false); ?>">Manage Users</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('adminroles.index'), false); ?>">Manage Role</a></li>
                            <li class="ms-3 nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name, false); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout'), false); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(('Logout'), false); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout'), false); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4 bg-light">
            <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>
</body>
</html> <?php /**PATH C:\Users\HP\Desktop\workspace\Movie\resources\views/layouts/master.blade.php ENDPATH**/ ?>