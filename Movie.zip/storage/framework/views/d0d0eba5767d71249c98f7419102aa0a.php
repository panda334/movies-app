<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

        <title><?php echo e(config('app.name', 'Laravel'), false); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>

    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100 dark:bg-gray-900">

        <div class="flex-col w-full md:flex md:flex-row md:min-h-screen">
            <div @click.away="open = false" class="flex flex-col flex-shrink-0 w-full text-gray-700 bg-white md:w-64 dark-mode:text-gray-200 dark-mode:bg-gray-800" x-data="{ open: false }">
                <div class="flex flex-row items-center justify-between flex-shrink-0 px-8 py-4">
                    <a href="#" class="text-lg font-semibold tracking-widest text-gray-900 uppercase rounded-lg dark-mode:text-white focus:outline-none focus:shadow-outline">Flowtrail UI</a>
                    <button class="rounded-lg md:hidden focus:outline-none focus:shadow-outline" @click="open = !open">
                        <svg fill="currentColor" viewBox="0 0 20 20" class="w-6 h-6">
                            <path x-show="!open" fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM9 15a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1z" clip-rule="evenodd"></path>
                            <path x-show="open" fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                        </svg>
                    </button>
                </div>
                    <nav :class="{'block': open, 'hidden': !open}" class="flex-grow px-4 pb-4 md:block md:pb-0 md:overflow-y-auto">

                        <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admincategories.index'),'active' => request()->routeIs('admincategories.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admincategories.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admincategories.index'))]); ?>
                            <?php echo e(__('Categories'), false); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>


                       
                        <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('adminmovies.index'),'active' => request()->routeIs('adminmovies.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('adminmovies.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('adminmovies.index'))]); ?>
                            <?php echo e(__('Movies'), false); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admincasts.index'),'active' => request()->routeIs('admincasts.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admincasts.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admincasts.index'))]); ?>
                            <?php echo e(__('Casts'), false); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admintraileres.index'),'active' => request()->routeIs('admintraileres.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admintraileres.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admintraileres.index'))]); ?>
                            <?php echo e(__('Trailers'), false); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('adminroles.index'),'active' => request()->routeIs('adminroles.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('adminroles.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('adminroles.index'))]); ?>
                            <?php echo e(__('Roles'), false); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('adminusers.index'),'active' => request()->routeIs('adminusers.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('adminusers.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('adminusers.index'))]); ?>
                            <?php echo e(__('Users'), false); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>

                      
                         
                        <div @click.away="open = false" class="relative" x-data="{ open: false }">
                            <button @click="open = !open" class="flex flex-row items-center w-full px-4 py-2 mt-2 text-sm font-semibold text-left bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:focus:bg-gray-600 dark-mode:hover:bg-gray-600 md:block hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline">
                                <span><?php echo e(Auth::user()->name, false); ?></span>
                                <svg fill="currentColor" viewBox="0 0 20 20" :class="{'rotate-180': open, 'rotate-0': !open}" class="inline w-4 h-4 mt-1 ml-1 transition-transform duration-200 transform md:-mt-1"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                            </button>
                            <div x-show="open" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="absolute right-0 w-full mt-2 origin-top-right rounded-md shadow-lg">
                                <div class="px-2 py-2 bg-white rounded-md shadow dark-mode:bg-gray-700">
                                    <form method="POST" action="<?php echo e(route('logout'), false); ?>">
                                        <?php echo csrf_field(); ?>
            
                                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                            this.closest(\'form\').submit();','class' => 'block px-4 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:hover:bg-gray-600 dark-mode:focus:bg-gray-600 dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:text-gray-200 md:mt-0 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                            this.closest(\'form\').submit();','class' => 'block px-4 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:hover:bg-gray-600 dark-mode:focus:bg-gray-600 dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:text-gray-200 md:mt-0 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline']); ?>
                                            <?php echo e(__('Log Out'), false); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </nav>
                    
            </div>
            <main>
                <?php echo e($slot, false); ?>

            </main>
        </div>
      </div>
    </body>
</html>
<?php /**PATH C:\Users\HP\Desktop\workspace\Movie\resources\views/layouts/admin.blade.php ENDPATH**/ ?>